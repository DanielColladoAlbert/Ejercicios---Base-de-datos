SELECT p.id_producto, p.nombre, l.importe_unitario, l.unidades 
FROM lineapedido l
left join producto p on p.id_producto=l.id_producto
left join categoria c on c.id_categoria=p.id_categoria

where l.id_producto = 1 and c.nombre in ('menaje') 