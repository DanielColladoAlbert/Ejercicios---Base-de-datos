SELECT nombre, apellido1, apellido2
FROM usuario
order by apellido1, apellido2, nombre;