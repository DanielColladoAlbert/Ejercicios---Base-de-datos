#Ejercicio_8
select *
from pedido
where fecha <'2017-10-01';