#Ejercicio_9
select id_producto, nombre, precio
from producto
where precio in (100,150, 200, 250)