SELECT id_producto, nombre, precio
from producto

where id_marca is not null and
precio between 1 and 10

order by precio desc