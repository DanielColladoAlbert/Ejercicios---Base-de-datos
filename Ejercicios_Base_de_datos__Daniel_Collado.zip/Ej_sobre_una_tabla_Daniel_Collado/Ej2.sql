#Ejercicio_2
select nombre, apellido1, apellido2, email
from usuario