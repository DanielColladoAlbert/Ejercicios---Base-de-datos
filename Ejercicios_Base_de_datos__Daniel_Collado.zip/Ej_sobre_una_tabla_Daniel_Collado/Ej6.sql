#Ejercicio_6
select nombre, apellido1, apellido2, email
from usuario
where nombre in ('maite', 'ana');