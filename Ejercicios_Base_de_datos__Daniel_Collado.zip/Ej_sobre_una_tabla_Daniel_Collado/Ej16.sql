SELECT id_producto, nombre, precio * 1.10 AS precio_incrementado
from producto 

