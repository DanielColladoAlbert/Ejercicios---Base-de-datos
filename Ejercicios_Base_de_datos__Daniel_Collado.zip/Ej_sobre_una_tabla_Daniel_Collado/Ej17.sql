SELECT nombre, apellido1, apellido2, fechanac, generacion
from usuario;

alter table usuario
ADD column generacion varChar(30) as
(Case
	when fechanac >= '1965-01-01' and fechanac <= '1980-12-31' then 'generacion X'
	when fechanac >= '1981-01-01' and fechanac <= '1995-12-31' then 'generacion Y'
	when fechanac >= '1996-01-01' and fechanac <= '2012-12-31' then 'generacion Z'
	else 'No registrado' 
End)