select nombre, apellido1, apellido2, dni
from usuario
where dni like '%b'or dni like'%q'or dni like'%z';

