select id_provincia, nombre
from provincia
where nombre not in ('toledo','cuenca','barcelona', 'murcia', 'sevilla')

