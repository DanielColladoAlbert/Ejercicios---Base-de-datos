#Ejercicio_4
select id_producto, importe_unitario
from lineapedido

where id_pedido = 1