SELECT codigo_postal, nombre, habitantes
from localidad

where habitantes > 1000 and
nombre like 'b%' or nombre like 'c%'

order by habitantes asc