SELECT id_usuario, dni, nombre, apellido1, apellido2, telefono, fechanac
from usuario

where dni like '3%' and
telefono is null and
fechanac between '1992-01-01' and '1992-12-31'

order by apellido1, nombre