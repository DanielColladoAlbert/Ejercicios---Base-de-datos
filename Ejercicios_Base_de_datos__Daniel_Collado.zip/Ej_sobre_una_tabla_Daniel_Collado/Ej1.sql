#Ejercicio_1
select *
from pais