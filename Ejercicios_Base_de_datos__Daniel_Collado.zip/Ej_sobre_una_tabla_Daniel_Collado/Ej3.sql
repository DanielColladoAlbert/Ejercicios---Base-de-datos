#Ejercicio_3
select id_producto, nombre, precio
from producto

where precio > 50