select nombre
from producto
where nombre like '%spir%'

