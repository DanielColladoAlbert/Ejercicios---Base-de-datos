#Ejercicio_10
select id_provincia, nombre
from provincia
WHERE nombre like 'al%';