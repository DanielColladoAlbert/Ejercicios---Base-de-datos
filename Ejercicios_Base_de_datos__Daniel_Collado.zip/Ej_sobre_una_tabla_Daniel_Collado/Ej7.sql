#Ejercicio_7
select id_producto, nombre, precio
from producto
where precio between 10 and 80