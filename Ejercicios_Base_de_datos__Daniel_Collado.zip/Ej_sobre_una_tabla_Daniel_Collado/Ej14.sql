select id_producto, nombre, precio
from producto
where id_marca is null
