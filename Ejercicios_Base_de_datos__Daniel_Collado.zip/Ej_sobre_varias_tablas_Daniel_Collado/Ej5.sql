SELECT u.id_usuario, u.nombre, u.apellido1, u.apellido2
FROM usuario u
join localidad l on l.id_localidad=u.id_localidad

where l.codigo_postal not in (03409 ,03661 ,04365)

