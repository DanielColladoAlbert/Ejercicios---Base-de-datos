SELECT p.id_pedido, u.dni, p.fecha, e.nombre as nombre_estado, f.nombre as nombre_formapago
from usuario u
left join pedido p on p.id_usuario = u.id_usuario
left join estado e on e.id_estado = p.id_estado
left join formapago f on f.id_formapago = p.id_formapago

where fecha between'2022-01-01' and '2022-12-31'
