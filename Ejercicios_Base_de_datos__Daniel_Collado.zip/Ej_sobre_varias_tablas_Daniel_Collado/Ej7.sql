select distinct lp.id_producto
from pedido p
left join lineapedido lp on p.id_pedido = lp.id_pedido
where p.fecha between '2021-03-01' and '2021-03-31'
order by lp.id_producto asc

