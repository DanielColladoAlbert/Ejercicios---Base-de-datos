select p.id_producto, p.nombre, p.precio, m.nombre, c.nombre
from producto p
left join marca m on m.id_marca = p.id_marca
left join categoria c on c.id_categoria = p.id_categoria

where m.nombre in ("hp", "lg" , "bosch") and
c.nombre in ("bricolaje" , "menaje")
order by p.nombre desc

