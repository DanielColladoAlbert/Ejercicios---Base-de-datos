select u.id_usuario, u.nombre, u.apellido1, p.id_producto, p.nombre,v.valoracion
from usuario u
left join valoracion v on v.id_usuario = u.id_usuario
left join producto p on p.id_producto = v.id_producto

where (p.precio < 50) and
(v.valoracion <= 3)

