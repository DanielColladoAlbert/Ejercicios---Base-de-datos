select p.id_pedido, u.email, u.nombre, u.apellido1, u.apellido2
from pedido p
left join usuario u on u.id_usuario = p.id_usuario
left join localidad l on l.id_localidad = u.id_localidad