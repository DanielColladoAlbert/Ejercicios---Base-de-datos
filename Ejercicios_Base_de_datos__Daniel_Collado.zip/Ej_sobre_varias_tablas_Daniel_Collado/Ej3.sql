SELECT l.nombre, p.nombre, pa.nombre
FROM localidad l
join provincia p on p.id_provincia=l.id_provincia
join pais pa on pa.id_pais=pa.id_pais
