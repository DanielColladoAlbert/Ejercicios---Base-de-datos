select l.nombre, pr.nombre
from localidad l
left join provincia pr on pr.id_provincia = l.id_provincia
where (pr.nombre = "valencia" or pr.nombre = "alicante" or pr.nombre = "castellon") and
l.nombre like "b%"
