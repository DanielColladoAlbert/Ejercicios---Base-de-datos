SELECT p.id_producto, p.nombre, m.nombre
from producto p
left join marca m on m.id_marca = p.id_marca


