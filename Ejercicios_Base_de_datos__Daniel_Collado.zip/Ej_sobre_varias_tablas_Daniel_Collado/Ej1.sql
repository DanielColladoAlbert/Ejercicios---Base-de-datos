SELECT p.id_producto, c.nombre 
from producto p
left join categoria c on c.id_categoria = p.id_categoria