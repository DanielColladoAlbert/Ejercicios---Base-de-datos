SELECT u.dni, u.nombre, u.fechanac, l.nombre, l.habitantes, p.nombre, pa.nombre
from usuario u
left join localidad l on l.id_localidad = u.id_localidad
left join provincia p on p.id_provincia = l.id_provincia
left join pais pa on pa.id_pais = p.id_pais

where u.nombre in ("pedro", "jose", "luis") and
p.nombre not in ("Valencia", "Alicante", "Castellon") and
l.habitantes > 1000 and
u.dni like "%7%" and 
u.fechanac >= 1/06/2000

