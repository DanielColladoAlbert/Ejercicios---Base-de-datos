SELECT u.dni, u.nombre, u.apellido1, u.apellido2
from usuario u
left join localidad l on l.id_localidad=u.id_localidad
left join provincia p on p.id_provincia=l.id_provincia
where p.nombre in ("alicante")