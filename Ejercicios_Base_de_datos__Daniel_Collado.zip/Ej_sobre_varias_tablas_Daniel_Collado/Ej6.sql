SELECT *
FROM pedido p
join usuario u on u.id_usuario=p.id_usuario

 where fecha>='2018-01-01' and fecha<='2018-12-31' and
 email like '%@gmail.com'


