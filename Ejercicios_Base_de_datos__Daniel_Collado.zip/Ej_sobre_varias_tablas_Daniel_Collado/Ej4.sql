select p.id_producto, p.nombre, l.importe_unitario, l.unidades
from producto p
left join lineapedido l on l.id_producto = p.id_producto
left join categoria c on c.id_categoria = p.id_categoria

where l.id_pedido = 1 and
c.nombre in ("menaje") 

