SELECT p.id_pedido, u.email, u.nombre, u.apellido1, u.apellido2, l.nombre
from usuario u
left join pedido p on p.id_usuario = u.id_usuario
left join localidad l on l.id_localidad = u.id_localidad