-- MySQL dump 10.13  Distrib 8.0.32, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: Peliculas
-- ------------------------------------------------------
-- Server version	8.0.34-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Actor`
--

DROP TABLE IF EXISTS `Actor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Actor` (
  `Nombre` varchar(20) NOT NULL,
  `Apellido` varchar(20) DEFAULT NULL,
  `DNI_actor` char(9) NOT NULL,
  PRIMARY KEY (`DNI_actor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Actor`
--

LOCK TABLES `Actor` WRITE;
/*!40000 ALTER TABLE `Actor` DISABLE KEYS */;
INSERT INTO `Actor` VALUES ('Tobey','Maguire','12358786N'),('Ryan ','Reinold','15643578L'),('Jonnhy','Deep','23782650M'),('Jason','Lee','65787692G'),('Will','Smith','67593293B');
/*!40000 ALTER TABLE `Actor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Critica`
--

DROP TABLE IF EXISTS `Critica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Critica` (
  `Codigo` int NOT NULL,
  `Estrellas` int DEFAULT NULL,
  `Critica` varchar(100) NOT NULL,
  `Codigo_pelicula` int NOT NULL,
  `correo_electronico` varchar(40) NOT NULL,
  PRIMARY KEY (`Codigo`),
  KEY `fk_Critica_Correo_electronico_idx` (`correo_electronico`),
  KEY `fk_Critica_Codigo_pelicula_idx` (`Codigo_pelicula`),
  CONSTRAINT `fk_Critica_Codigo_pelicula` FOREIGN KEY (`Codigo_pelicula`) REFERENCES `Pelicula` (`Codigo_Pelicula`),
  CONSTRAINT `fk_Critica_Correo_electronico` FOREIGN KEY (`correo_electronico`) REFERENCES `Usuario` (`Correo_electronico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Critica`
--

LOCK TABLES `Critica` WRITE;
/*!40000 ALTER TABLE `Critica` DISABLE KEYS */;
INSERT INTO `Critica` VALUES (1,7,'Muy buena',1,'KevinDiaz@gmail.com'),(2,6,'Ha estado bien',2,'MariaGomez@gmail.com'),(3,9,'Me ha encantado',3,'Pacopepe@gmail.com'),(4,5,'Sin mas',4,'SaraHernandez@gmail.com'),(5,9,'Muy buena',5,'DanielFernandez@gmail.com');
/*!40000 ALTER TABLE `Critica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Director`
--

DROP TABLE IF EXISTS `Director`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Director` (
  `DNI_director` char(9) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Apellido` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`DNI_director`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Director`
--

LOCK TABLES `Director` WRITE;
/*!40000 ALTER TABLE `Director` DISABLE KEYS */;
INSERT INTO `Director` VALUES ('12345678K','Tim','Miller'),('12378345K','Gary','Gray'),('19283746K','Betty','Thomas'),('34512378K','Sam','Raimi'),('87654321K','Rob','Marshall');
/*!40000 ALTER TABLE `Director` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Genero`
--

DROP TABLE IF EXISTS `Genero`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Genero` (
  `Codigo_genero` int NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  PRIMARY KEY (`Codigo_genero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Genero`
--

LOCK TABLES `Genero` WRITE;
/*!40000 ALTER TABLE `Genero` DISABLE KEYS */;
INSERT INTO `Genero` VALUES (1,'Accion'),(2,'Accion/Aventura'),(3,'Disparos'),(4,'Superheroe'),(5,'Familiar');
/*!40000 ALTER TABLE `Genero` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Interpreta`
--

DROP TABLE IF EXISTS `Interpreta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Interpreta` (
  `DNI_actor` char(9) NOT NULL,
  `Codigo_película` int NOT NULL,
  PRIMARY KEY (`DNI_actor`,`Codigo_película`),
  KEY `fk_Interpreta_Código pelicula_idx` (`Codigo_película`),
  CONSTRAINT `fk_Interpreta_Código pelicula` FOREIGN KEY (`Codigo_película`) REFERENCES `Pelicula` (`Codigo_Pelicula`),
  CONSTRAINT `fk_Interpreta_DNI actor` FOREIGN KEY (`DNI_actor`) REFERENCES `Actor` (`DNI_actor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Interpreta`
--

LOCK TABLES `Interpreta` WRITE;
/*!40000 ALTER TABLE `Interpreta` DISABLE KEYS */;
INSERT INTO `Interpreta` VALUES ('12358786N',1),('15643578L',2),('23782650M',3),('65787692G',4),('67593293B',5);
/*!40000 ALTER TABLE `Interpreta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pelicula`
--

DROP TABLE IF EXISTS `Pelicula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Pelicula` (
  `Codigo_Pelicula` int NOT NULL,
  `Titulo` varchar(20) NOT NULL,
  `Year` int DEFAULT NULL,
  `Duracion` time DEFAULT NULL,
  `Argumento` varchar(100) NOT NULL,
  `Imagen` blob,
  `DNI_director` char(9) DEFAULT NULL,
  `Codigo_genero` int NOT NULL,
  PRIMARY KEY (`Codigo_Pelicula`),
  KEY `fk_Película_Código género_idx` (`Codigo_genero`),
  KEY `fk_Pelicula_DNI_director_idx` (`DNI_director`),
  CONSTRAINT `fk_Pelicula_COdigo_genero` FOREIGN KEY (`Codigo_genero`) REFERENCES `Genero` (`Codigo_genero`),
  CONSTRAINT `fk_Pelicula_DNI_director` FOREIGN KEY (`DNI_director`) REFERENCES `Director` (`DNI_director`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pelicula`
--

LOCK TABLES `Pelicula` WRITE;
/*!40000 ALTER TABLE `Pelicula` DISABLE KEYS */;
INSERT INTO `Pelicula` VALUES (1,'Deadpool',2015,'01:30:00','Antiheroe derrotando a los malos',NULL,'12345678K',1),(2,'Piratas del caribe',2009,'01:15:00','Capitan de barco crea una tripulacion y derrota a los malos rompiendo la maldicion que los atenian',NULL,'87654321K',2),(3,'Men in black',2002,'01:20:00','Dos agentes secrestos derrotan a los aliens que vienen a invadir la tierra',NULL,'12378345K',3),(4,'Spider-Man',2001,'01:00:00','Adolescente consigue poderes y derrota a los villanos gracias a ellos ellos',NULL,'34512378K',4),(5,'Alvin y las ardillas',2008,'01:45:00','Ardillas antropomorficas se hacen cantantes y viven alocadas aventuras',NULL,'19283746K',5);
/*!40000 ALTER TABLE `Pelicula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuario`
--

DROP TABLE IF EXISTS `Usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Usuario` (
  `Correo_electronico` varchar(40) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Apellido` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Correo_electronico`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuario`
--

LOCK TABLES `Usuario` WRITE;
/*!40000 ALTER TABLE `Usuario` DISABLE KEYS */;
INSERT INTO `Usuario` VALUES ('DanielFernandez@gmail.com','fdhgjhfgjghk','Daniel','Fernandez'),('KevinDiaz@gmail.com','aswdfre','Kevin','Diaz'),('MariaGomez@gmail.com','987654321','Maria','Gomez'),('Pacopepe@gmail.com','123456789','Paco','Perez'),('SaraHernandez@gmail.com','135790864','Sara','Hernandez');
/*!40000 ALTER TABLE `Usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06 15:49:57
