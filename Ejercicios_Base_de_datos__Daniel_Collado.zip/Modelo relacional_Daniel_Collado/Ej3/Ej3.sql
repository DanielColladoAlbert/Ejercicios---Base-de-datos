#Ejercicio_2
select id_producto, nombre, precio
from producto